package com.velnoxy.amrpc

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var statusView: TextView
    private lateinit var accessView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            gravity = Gravity.TOP
        }

        root.addView(TextView(this).apply {
            text = "Apple Music → Discord"
            textSize = 22f
        })

        statusView = TextView(this).apply { setPadding(0, pad, 0, 0) }
        root.addView(statusView)

        accessView = TextView(this).apply { setPadding(0, pad / 2, 0, pad) }
        root.addView(accessView)

        val tokenInput = EditText(this).apply {
            hint = "Discord token"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
        }
        root.addView(tokenInput)

        val appIdInput = EditText(this).apply {
            hint = "Application ID (albüm kapağı için)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine()
            setText(TokenStore.getAppId(context) ?: "")
        }
        root.addView(appIdInput)

        root.addView(Button(this).apply {
            text = "Kaydet ve bağlan"
            setOnClickListener {
                val id = appIdInput.text.toString().trim()
                TokenStore.saveAppId(context, id)
                DiscordPresence.appId = id

                val t = tokenInput.text.toString().trim().trim('"')
                if (t.isNotEmpty()) {
                    TokenStore.save(context, t)
                    tokenInput.setText("")
                    DiscordPresence.connect(t)
                } else if (TokenStore.get(context) == null) {
                    Toast.makeText(context, "Token boş", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                Toast.makeText(context, "Kaydedildi", Toast.LENGTH_SHORT).show()
            }
        })

        root.addView(Button(this).apply {
            text = "Bildirim erişimi ayarlarını aç"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        })

        root.addView(Button(this).apply {
            text = "Bağlantıyı kes ve token'ı sil"
            setOnClickListener {
                DiscordPresence.disconnect()
                TokenStore.clear(context)
            }
        })

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        DiscordPresence.onStatus = { statusView.text = "Durum: $it" }
        statusView.text = "Durum: ${DiscordPresence.status}"
        accessView.text = if (hasListenerAccess()) {
            "Bildirim erişimi: açık"
        } else {
            "Bildirim erişimi: KAPALI (aşağıdan açıp bu uygulamayı etkinleştir)"
        }
        TokenStore.get(this)?.let { DiscordPresence.connect(it) }
    }

    override fun onPause() {
        super.onPause()
        DiscordPresence.onStatus = null
    }

    private fun hasListenerAccess(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?: return false
        val me = ComponentName(this, MediaListenerService::class.java)
        return flat.split(":").any { ComponentName.unflattenFromString(it) == me }
    }
}
