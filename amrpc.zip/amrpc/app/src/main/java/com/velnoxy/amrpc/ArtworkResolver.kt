package com.velnoxy.amrpc

import android.util.LruCache
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/**
 * Albüm kapagini iTunes Search API'den bulur, ardindan Discord'un external-assets
 * ucuna kaydederek presence'ta kullanilabilir "mp:external/..." yolunu alir.
 * Bu islem arka plan thread'inde cagrilmali (ag istegi yapar).
 */
object ArtworkResolver {
    private val client = OkHttpClient()
    private val cache = LruCache<String, String>(64)
    private val json = "application/json".toMediaType()

    fun resolve(appId: String, token: String, track: Track): String? {
        val key = "${track.artist}|${track.album ?: track.title}"
        cache.get(key)?.let { return it }
        return try {
            val art = itunesArtwork(track) ?: return null
            val mp = externalAsset(appId, token, art) ?: return null
            cache.put(key, mp)
            mp
        } catch (e: Exception) {
            null
        }
    }

    private fun itunesArtwork(track: Track): String? {
        val hasAlbum = !track.album.isNullOrBlank()
        val term = if (hasAlbum) "${track.artist} ${track.album}" else "${track.artist} ${track.title}"
        val url = "https://itunes.apple.com/search".toHttpUrl().newBuilder()
            .addQueryParameter("term", term)
            .addQueryParameter("entity", if (hasAlbum) "album" else "song")
            .addQueryParameter("limit", "1")
            .build()
        client.newCall(Request.Builder().url(url).build()).execute().use { resp ->
            if (!resp.isSuccessful) return null
            val results = JSONObject(resp.body?.string() ?: return null).optJSONArray("results")
            val first = results?.optJSONObject(0) ?: return null
            val small = first.optString("artworkUrl100").ifEmpty { return null }
            return small.replace("100x100", "600x600")
        }
    }

    private fun externalAsset(appId: String, token: String, imageUrl: String): String? {
        val body = JSONObject().put("urls", JSONArray().put(imageUrl)).toString().toRequestBody(json)
        val req = Request.Builder()
            .url("https://discord.com/api/v9/applications/$appId/external-assets")
            .header("Authorization", token)
            .post(body)
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return null
            val arr = JSONArray(resp.body?.string() ?: return null)
            val path = arr.optJSONObject(0)?.optString("external_asset_path").orEmpty()
            return if (path.isEmpty()) null else "mp:$path"
        }
    }
}
