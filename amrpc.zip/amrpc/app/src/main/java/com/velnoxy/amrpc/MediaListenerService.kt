package com.velnoxy.amrpc

import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.service.notification.NotificationListenerService

/**
 * Bildirim erisimi izni sayesinde sistemin medya oturumlarini okur.
 * Apple Music (com.apple.android.music) oturumundaki sarki bilgisini Discord'a iletir.
 */
class MediaListenerService : NotificationListenerService() {

    companion object {
        const val APPLE_MUSIC = "com.apple.android.music"
    }

    private var msm: MediaSessionManager? = null
    private var controller: MediaController? = null
    private var lastKey: String? = null

    private val component by lazy { ComponentName(this, MediaListenerService::class.java) }

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = push()
        override fun onPlaybackStateChanged(state: PlaybackState?) = push()
        override fun onSessionDestroyed() {
            lastKey = null
            DiscordPresence.clear()
        }
    }

    override fun onListenerConnected() {
        val m = getSystemService(MediaSessionManager::class.java)
        msm = m
        m.addOnActiveSessionsChangedListener(sessionsListener, component)
        DiscordPresence.appId = TokenStore.getAppId(this)
        TokenStore.get(this)?.let { DiscordPresence.connect(it) }
        pick(m.getActiveSessions(component))
    }

    override fun onListenerDisconnected() {
        msm?.removeOnActiveSessionsChangedListener(sessionsListener)
        controller?.unregisterCallback(callback)
        controller = null
        DiscordPresence.clear()
    }

    private fun pick(list: List<MediaController>?) {
        val found = list?.firstOrNull { it.packageName == APPLE_MUSIC }
        if (found?.sessionToken == controller?.sessionToken) {
            push()
            return
        }
        controller?.unregisterCallback(callback)
        controller = found
        found?.registerCallback(callback)
        lastKey = null
        if (found == null) DiscordPresence.clear() else push()
    }

    private fun push() {
        val c = controller ?: return
        val state = c.playbackState
        val md = c.metadata
        if (state == null || md == null || state.state != PlaybackState.STATE_PLAYING) {
            if (lastKey != "paused") {
                lastKey = "paused"
                DiscordPresence.clear()
            }
            return
        }

        val title = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return
        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: "Bilinmeyen sanatci"
        val album = md.getString(MediaMetadata.METADATA_KEY_ALBUM)
        val duration = md.getLong(MediaMetadata.METADATA_KEY_DURATION)

        val elapsed = SystemClock.elapsedRealtime() - state.lastPositionUpdateTime
        val position = (state.position + (elapsed * state.playbackSpeed).toLong())
            .coerceIn(0L, if (duration > 0) duration else Long.MAX_VALUE)

        // Ayni sarki icin gereksiz tekrar gonderimi engelle (konum kaymasi 3 sn'den azsa)
        val key = "$title|$artist|${position / 3000}"
        if (key == lastKey) return
        lastKey = key

        DiscordPresence.update(Track(title, artist, album, duration, position))
    }
}
