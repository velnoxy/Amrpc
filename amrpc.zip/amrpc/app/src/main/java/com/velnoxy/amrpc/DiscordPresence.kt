package com.velnoxy.amrpc

import android.os.Handler
import android.os.Looper
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject

data class Track(
    val title: String,
    val artist: String,
    val album: String?,
    val durationMs: Long,
    val positionMs: Long,
)

/**
 * Discord Gateway'e kullanici token'i ile baglanir ve "Dinliyor" aktivitesi yollar.
 * NOT: Kullanici token'i ile otomasyon Discord ToS'a aykiridir (self-bot).
 */
object DiscordPresence {
    private const val GATEWAY = "wss://gateway.discord.gg/?v=10&encoding=json"

    private val client = OkHttpClient()
    private val main = Handler(Looper.getMainLooper())

    private var ws: WebSocket? = null
    private var token: String? = null
    private var wantConnected = false
    private var ready = false
    private var seq: Int? = null
    private var pending: Track? = null
    private var pendingArt: String? = null
    private var heartbeat: Runnable? = null

    /** Developer Portal'da olusturulan uygulamanin ID'si (albüm kapagi icin gerekli). */
    @Volatile var appId: String? = null

    @Volatile var status: String = "Bagli degil"
        private set
    var onStatus: ((String) -> Unit)? = null

    private fun setStatus(s: String) {
        status = s
        main.post { onStatus?.invoke(s) }
    }

    @Synchronized
    fun connect(newToken: String) {
        if (wantConnected && token == newToken && ws != null) return
        token = newToken
        wantConnected = true
        open()
    }

    @Synchronized
    fun disconnect() {
        wantConnected = false
        stopHeartbeat()
        ws?.close(1000, null)
        ws = null
        ready = false
        setStatus("Bagli degil")
    }

    @Synchronized
    fun update(track: Track) {
        pending = track
        pendingArt = null
        if (ready) sendPresence(track, null)

        val id = appId
        val tk = token
        if (id.isNullOrBlank() || tk == null) return
        Thread {
            val art = ArtworkResolver.resolve(id, tk, track) ?: return@Thread
            synchronized(this@DiscordPresence) {
                // Sarki bu arada degistiyse eski kapagi gonderme
                if (pending === track) {
                    pendingArt = art
                    if (ready) sendPresence(track, art)
                }
            }
        }.start()
    }

    @Synchronized
    fun clear() {
        pending = null
        pendingArt = null
        if (ready) sendPresence(null, null)
    }

    private fun open() {
        stopHeartbeat()
        ws?.cancel()
        ready = false
        seq = null
        setStatus("Baglaniyor...")
        ws = client.newWebSocket(Request.Builder().url(GATEWAY).build(), listener)
    }

    private fun scheduleReconnect() {
        if (!wantConnected) return
        setStatus("Yeniden baglaniliyor...")
        main.postDelayed({ if (wantConnected) open() }, 5000)
    }

    private fun stopHeartbeat() {
        heartbeat?.let { main.removeCallbacks(it) }
        heartbeat = null
    }

    private fun startHeartbeat(intervalMs: Long) {
        stopHeartbeat()
        val r = object : Runnable {
            override fun run() {
                sendHeartbeat()
                main.postDelayed(this, intervalMs)
            }
        }
        heartbeat = r
        // Ilk heartbeat'e jitter uygula
        main.postDelayed(r, (intervalMs * Math.random()).toLong())
    }

    private fun sendHeartbeat() {
        val d: Any = seq ?: JSONObject.NULL
        ws?.send(JSONObject().put("op", 1).put("d", d).toString())
    }

    private fun sendIdentify() {
        val props = JSONObject()
            .put("os", "android")
            .put("browser", "Discord Android")
            .put("device", "Discord Android")
        val d = JSONObject()
            .put("token", token)
            .put("properties", props)
            .put("intents", 0)
        ws?.send(JSONObject().put("op", 2).put("d", d).toString())
    }

    private fun pad(s: String): String {
        val t = s.take(128)
        return if (t.length < 2) t.padEnd(2, ' ') else t
    }

    private fun sendPresence(track: Track?, art: String?) {
        val activities = JSONArray()
        if (track != null) {
            val now = System.currentTimeMillis()
            val start = now - track.positionMs
            val activity = JSONObject()
                .put("name", "Apple Music")
                .put("type", 2) // Listening
                .put("details", pad(track.title))
                .put("state", pad(track.artist))
            appId?.takeIf { it.isNotBlank() }?.let { activity.put("application_id", it) }
            if (track.durationMs > 0) {
                activity.put(
                    "timestamps",
                    JSONObject().put("start", start).put("end", start + track.durationMs)
                )
            }
            if (art != null) {
                activity.put(
                    "assets",
                    JSONObject()
                        .put("large_image", art)
                        .put("large_text", pad(track.album ?: track.title))
                )
            }
            activities.put(activity)
        }
        val d = JSONObject()
            .put("since", JSONObject.NULL)
            .put("activities", activities)
            .put("status", "online")
            .put("afk", false)
        ws?.send(JSONObject().put("op", 3).put("d", d).toString())
    }

    private val listener = object : WebSocketListener() {
        override fun onMessage(webSocket: WebSocket, text: String) {
            val msg = JSONObject(text)
            if (!msg.isNull("s")) seq = msg.getInt("s")
            when (msg.getInt("op")) {
                10 -> {
                    val interval = msg.getJSONObject("d").getLong("heartbeat_interval")
                    startHeartbeat(interval)
                    sendIdentify()
                }
                1 -> sendHeartbeat()
                0 -> if (msg.optString("t") == "READY") {
                    synchronized(this@DiscordPresence) {
                        ready = true
                        setStatus("Bagli")
                        pending?.let { sendPresence(it, pendingArt) }
                    }
                }
                7, 9 -> { // Reconnect / Invalid session
                    webSocket.close(4000, "reconnect")
                }
            }
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            ready = false
            stopHeartbeat()
            if (code == 4004) { // Authentication failed
                wantConnected = false
                setStatus("Token gecersiz")
            } else {
                scheduleReconnect()
            }
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            ready = false
            stopHeartbeat()
            scheduleReconnect()
        }
    }
}
