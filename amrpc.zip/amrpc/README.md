# AM RPC — Apple Music → Discord (Android)

Apple Music'te çalan şarkıyı Discord profiline "Dinliyor" aktivitesi olarak yansıtır.

## Derleme
- **GitHub Actions (önerilen):** Projeyi bir GitHub deposuna it. Actions sekmesinde "Build APK" çalışır, bitince Artifacts bölümünden `amrpc-debug-apk` içindeki `app-debug.apk` dosyasını indir.
- **Android Studio:** `amrpc` klasörünü aç, Gradle sync bitsin (sürümler eskiyse Studio güncelleme önerir), telefonda çalıştır.

## Albüm kapağı için bir kerelik hazırlık
Discord Developer Portal'da (discord.com/developers/applications) "New Application" ile bir uygulama oluştur, adını `Apple Music` yap (Discord'da etkinlik adı olarak bu görünür). General Information sayfasındaki **Application ID**'yi kopyala.

## Kullanım
1. APK'yı kur, uygulamada "Bildirim erişimi ayarlarını aç" → AM RPC'yi etkinleştir.
2. Token ve Application ID'yi gir, "Kaydet ve bağlan"a bas. Durum "Bağlı" olunca Apple Music'te şarkı çal.
3. Pil optimizasyonundan uygulamayı muaf tut (yoksa Android arka planda kapatabilir).
4. Application ID boş bırakılırsa presence yine çalışır, sadece kapak görünmez.

## Nasıl çalışır
- `MediaListenerService`: Bildirim erişimiyle `com.apple.android.music` medya oturumunu izler (şarkı, sanatçı, albüm, süre, konum).
- `DiscordPresence`: Discord Gateway'e WebSocket ile bağlanır, token ile IDENTIFY yapar, şarkı değiştikçe presence (op 3, type 2) yollar.
- `TokenStore`: Token'ı Android Keystore'daki AES-GCM anahtarıyla şifreli saklar; yedeğe dahil edilmez.

## Uyarılar
- Kullanıcı token'ıyla otomasyon Discord ToS'a aykırıdır; hesap uyarı/kapatma riski taşır.
- Token'ı kimseyle paylaşma, depoya/ekran görüntüsüne koyma. Şüphelenirsen şifreni değiştir (token yenilenir).

## Albüm kapağı nasıl çalışır
`ArtworkResolver` kapağı iTunes Search API'den bulur, Discord'un external-assets ucuna kaydedip `mp:external/...` yolunu alır. Şarkı önce kapaksız gösterilir, kapak bulununca presence güncellenir.

## Henüz yok
- Foreground service (şimdilik NotificationListenerService'in sistem tarafından canlı tutulmasına güveniyor).
